package com.leyou.item.mapper;

import com.leyou.item.pojo.SpecParam;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: cuzz
 * @Date: 2018/11/5 16:28
 * @Description:
 */
public interface SpecParamMapper extends Mapper<SpecParam> {
}
