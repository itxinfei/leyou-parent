package com.leyou.item.mapper;

import com.leyou.item.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: cuzz
 * @Date: 2018/11/7 19:17
 * @Description:
 */
public interface SkuMapper extends Mapper<Sku>{
}
