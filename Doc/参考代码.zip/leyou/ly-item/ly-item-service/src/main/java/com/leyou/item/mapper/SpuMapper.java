package com.leyou.item.mapper;

import com.leyou.item.pojo.Spu;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: cuzz
 * @Date: 2018/11/6 19:44
 * @Description:
 */
public interface SpuMapper extends Mapper<Spu>{
}
