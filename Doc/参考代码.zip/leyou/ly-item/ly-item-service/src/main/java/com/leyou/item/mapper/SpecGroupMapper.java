package com.leyou.item.mapper;

import com.leyou.item.pojo.SpecGroup;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: cuzz
 * @Date: 2018/11/5 13:53
 * @Description:
 */
public interface SpecGroupMapper extends Mapper<SpecGroup>{
}
