package com.leyou.item.mapper;

import com.leyou.item.pojo.SpuDetail;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: cuzz
 * @Date: 2018/11/6 19:45
 * @Description:
 */
public interface SpuDetailMapper extends Mapper<SpuDetail>{
}
